package RiskGame.Logic;

public enum  GameState {
    RandomDeal, ReinForce, Attack, Fortify
}
