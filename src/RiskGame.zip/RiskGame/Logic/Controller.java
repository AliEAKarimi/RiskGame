package RiskGame.Logic;

import RiskGame.Logic.Board;
import RiskGame.Logic.Player;
import RiskGame.UI.GUI;

import java.util.List;

public class Controller  {

    private GUI gui;
    private Board board;
    private List<Player> players;
    private int PlayersCount;

    public Controller(List<Player> players) {
        this.players = players;
    }
    public Controller(GUI gui, Board board) {
        this.gui = gui;
        this.board = board;
    }



}

class PlayerCountController {


    public PlayerCountController() {

    }


}