package RiskGame.Logic;

import java.util.ArrayList;
import java.util.List;

public class Board {

    private Map map;
    private List<Land> lands;
    private List<Continent> continents;
    private boolean isAbutting;
    private List<Land> emptyLands;
    //private List<Land> occupiedLands;
    private int playerCount;
    private List<Player> players;
    private Land selectedLand;
    private Player playerInTurn;
    private List<Land> memberLands;
    public Board() {
        map = new Map();
        initializationBoard();
    }
    public void initializationBoard() {
        lands = map.getLands();
        continents = map.getContinents();
        //playerCount = map.get
    }

    public void setPlayerCount(int playerCount) {
        this.playerCount = playerCount;
    }
    public List<Player> getPlayers() {
        return players;
    }
    public int getPlayerCount() {
        return playerCount;
    }

    //return all continent.
    public List<Continent> getContinents() {
        return continents;
    }

    //assignment and return the lands that is empty
    public List<Land> getEmptyLands() {
        emptyLands = new ArrayList<>();
        for (Land land : lands) {
            if(land.isEmpty())
                emptyLands.add(land);
        }
        return emptyLands;
    }
    public List<Land> getLands() {
        return lands;
    }
    public List<Land> getMemberLands(Continent continent) {
        return continent.getLands();
    }

    //put soldier by player in a "his" lands.
    public void putSoldierByPlayer(Player player, Land land){
        player.putSoldier(land);
    }
    //for after attack if a land game over.move soldiers that alive to game over land.
    public void addSoldier(List<Soldier> soldiers, Land land) {
        land.addSoldier(soldiers);
    }
    //return the number of Land Soldiers.
    public int getNumOfSoldier(Land land) {
        return land.getNumOfSoldier();
    }

    public int getAwardingSoldiers(Continent continent) {
        return continent.getAwardingSoldiers();
    }

    public void setOccupied(Land occupied, Player occupant) {
        occupied.setOccupied(occupant);
    }

    public void setSelectedLand(Land selectedLand) {
        this.selectedLand = selectedLand;
    }
    public Land getSelectedLand() {
        return selectedLand;
    }

    public Player getPlayerInTurn() {
        for (Player player : players)
            if (player.isHandout())
                return player;
        return null;
    }

    public List<Land> getAbuttingLands(Land land) {
        return land.getAbuttingLands();
    }
    public boolean isAbutting(Land landA, Land landB) {
        if (landA.getAbuttingLands().contains(landB)) {
            isAbutting = true;
        } else {
            isAbutting = false;
        }
        return isAbutting;
    }

}
