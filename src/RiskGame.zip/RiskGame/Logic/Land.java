package RiskGame.Logic;

import java.util.ArrayList;
import java.util.List;

public class Land {

    private int ID;
    private String name;
    private List<Soldier> soldiers;
    private int numOfSoldier;
    private Player commander;
    private List<Land> abuttingLands;
    private boolean isEmpty = true;
    //private Color color;

    public Land(int ID, String name) {
        this.ID = ID;
        this.name = name;
        soldiers = new ArrayList<>();
    }

    //I think below method can implement in player class
    public void addSoldier(Soldier soldier) {
        soldiers.add(soldier);
        soldier.setStateSoldier(StateSoldier.PLACED);
    }
    public void addSoldier(List<Soldier> soldiers) { //for time war that winner soldier must add to land that game over.
        for (Soldier soldier : soldiers) {
            addSoldier(soldier);
        }
    }
    public void removeSoldier(int id) {
        outer :for (Soldier soldier : soldiers) {
            inner : if (soldier.getId() == id) {
                soldiers.remove(soldier);
                break outer;
            }
        }
    }
    public int getNumOfSoldier() {
        return numOfSoldier = soldiers.size();
    }

    public String getName() {
        return name;
    }

    public void setOccupied(Player occupant) {
        commander = occupant;
        isEmpty = false;
    }

    public boolean isEmpty() {
        return isEmpty;
    }

    public Player getCommander() {
        return commander;
    }

    public void setAbuttingLands(List<Land> abuttingLands) {
        this.abuttingLands = abuttingLands;
    }
    public List<Land> getAbuttingLands() {
        return abuttingLands;
    }

    public int getID() {
        return ID;
    }
    /*public void setColor(Color color) {
        this.color = color;
    }
    public Color getColor() {
        return color;
    }*/
}
