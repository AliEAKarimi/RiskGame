package RiskGame.Logic;

public class Utils {
}
