package RiskGame.UI;

import javax.swing.*;

public class PlayNowPage extends JPanel {
    private JButton newGameBtn;
    private JButton loadGameBtn;


}
