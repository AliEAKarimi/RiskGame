package RiskGame.UI;

import RiskGame.Logic.Controller;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.Timer;

import static RiskGame.UI.Auxiliary.*;
import static java.lang.Thread.sleep;

public class MainPage extends JPanel implements MouseListener, ActionListener {

    private Controller controller;

    private JFrame owner;
    private JButton playNowBtn;
    private ImageIcon playNowImageIc2;
    private ImageIcon playNowImageIc1;
    private String playNowBtnName = "playNowBtn";

    private JButton optionBtn;
    private ImageIcon optionImageIc1;
    private ImageIcon optionImageIc2;
    private String optionBtnName = "optionBtn";

    private JButton rulesBtn;
    private ImageIcon rulesImageIc1;
    private ImageIcon rulesImageIc2;
    private String rulesBtnName;

    private JButton exitBtn;
    private ImageIcon exitImageIc1;
    private ImageIcon exitImageIc2;
    private String exitBtnName = "exitBtn";

    private JLabel backgroundJL;
    private ImageIcon backgroundIc;

    private JButton newGameBtn;
    private ImageIcon newGameImageIc1;
    private ImageIcon newGameImageIc2;
    private String newGameBtnName;

    private JButton loadGameBtn;
    private ImageIcon loadGameIc1;
    private ImageIcon loadGameIc2;
    private String loadGameBtnName;

    private JButton menuBtn;
    private ImageIcon menuImageIc1;
    private ImageIcon menuImageIc2;
    private String menuBtnName;

    private JButton backBtn;
    private ImageIcon backImageIc1;
    private ImageIcon backImageIc2;
    private String backBtnName;

    private JLabel playerCountJL;
    private String[] playerCountStr;
    private JRadioButton playerCountJRB1;
    private JRadioButton playerCountJRB2;
    private JRadioButton playerCountJRB3;
    private JTextField player1Name;
    private JTextField player2Name;
    private JTextField player3Name;
    private JTextField player4Name;
    private JButton confirmBtn;
    private ImageIcon confirmImageIc1;
    private ImageIcon confirmImageIc2;
    private JLabel player1JL;
    private JLabel player2JL;
    private JLabel player3JL;
    private JLabel player4JL;

    private JLabel mainPageJL;
    private ImageIcon mainPageJLImageIc;

    public MainPage(JFrame owner) {
        this.owner = owner;
        initPanel();
        setMainPageImage();
        setButtons();
    }

    public void initPanel(){
        setBackground(Color.black);
        setBounds(0, 0, WIDTH_SCREEN, HEIGHT_SCREEN);

    }
    private void setMainPageImage() {
        mainPageJL = new JLabel();
        mainPageJLImageIc = new ImageIcon("Logo1.jpg");
        mainPageJL.setIcon(mainPageJLImageIc);
        add(mainPageJL);
    }
    private void setButtons() {
        playNowBtn = new JButton();
        playNowImageIc1 = new ImageIcon("icon\\button\\playNow1.jpg");
        playNowImageIc2 = new ImageIcon("icon\\button\\playNow2.jpg");
        playNowBtn.setIcon(playNowImageIc1);
        playNowBtn.setBounds(1240, 480, playNowImageIc1.getIconWidth(), playNowImageIc1.getIconHeight());
        //playNowBtn.setEnabled();
        //Auxiliary.setOffBtn(playNowBtn);
        playNowBtn.setActionCommand(playNowBtnName);
        playNowBtn.addActionListener(this);
        playNowBtn.addMouseListener(this);
        playNowBtn.setEnabled(true);
        playNowBtn.setVisible(true);
        mainPageJL.add(playNowBtn);

        optionBtn = new JButton();
        optionImageIc1 = new ImageIcon("icon\\button\\option1.jpg");
        optionImageIc2 = new ImageIcon("icon\\button\\option2.jpg");
        optionBtn.setIcon(optionImageIc1);
        optionBtn.setBounds(1295,580, optionImageIc1.getIconWidth(), optionImageIc1.getIconHeight());
        optionBtn.setActionCommand(optionBtnName);
        optionBtn.addMouseListener(this);
        optionBtn.setVisible(true);
        mainPageJL.add(optionBtn);

        rulesBtn = new JButton();
        rulesImageIc1 = new ImageIcon("icon\\button\\Rules1.jpg");
        rulesImageIc2 = new ImageIcon("icon\\button\\Rules2.jpg");
        rulesBtn.setIcon(rulesImageIc1);
        rulesBtn.setBounds(1350, 660, rulesImageIc1.getIconWidth(), rulesImageIc1.getIconHeight());
        rulesBtn.setActionCommand(rulesBtnName);
        rulesBtn.addMouseListener(this);
        rulesBtn.setVisible(true);
        mainPageJL.add(rulesBtn);

        exitBtn = new JButton();
        exitImageIc1 = new ImageIcon("icon\\button\\quit1.jpg");
        exitImageIc2 = new ImageIcon("icon\\button\\6.jpg");
        exitBtn.setIcon(exitImageIc1);
        exitBtn.setBounds(1400, 720, exitImageIc1.getIconWidth(), exitImageIc1.getIconHeight());
        exitBtn.setActionCommand(exitBtnName);
        exitBtn.addActionListener(this);
        exitBtn.addMouseListener(this);
        exitBtn.setVisible(true);
        mainPageJL.add(exitBtn);
    }

    public void playNowAction() {
        mainPageJL.remove(rulesBtn);
        mainPageJL.remove(exitBtn);
        mainPageJL.remove(optionBtn);
        mainPageJL.revalidate();
        mainPageJL.repaint();

        new Timer(1, e -> Auxiliary.moveVerticalComponent(mainPageJL, playNowBtn, 200)).start();

        playNowBtn.setEnabled(false);

        backgroundJL = new JLabel();
        backgroundIc = new ImageIcon("icon\\button\\background.jpg");
        backgroundJL.setIcon(backgroundIc);
        backgroundJL.setBounds(1270, 300, backgroundIc.getIconWidth(), backgroundIc.getIconHeight());


        newGameBtn = new JButton();
        newGameImageIc1 = new ImageIcon("icon\\button\\newGame11.jpg");
        newGameImageIc2 = new ImageIcon("icon\\button\\newGame22.jpg");
        newGameBtn.setIcon(newGameImageIc1);
        newGameBtn.setBounds(1290, 360, newGameImageIc1.getIconWidth(), newGameImageIc1.getIconHeight());
        newGameBtn.setActionCommand(newGameBtnName);
        newGameBtn.addActionListener(this);
        newGameBtn.addMouseListener(this);
        newGameBtn.setVisible(true);
        mainPageJL.add(newGameBtn);


        loadGameBtn = new JButton();
        loadGameIc1 = new ImageIcon("icon\\button\\continue1.jpg");
        loadGameIc2 = new ImageIcon("icon\\button\\continue2.jpg");
        loadGameBtn.setIcon(loadGameIc1);
        loadGameBtn.setBounds(1290, 460, loadGameIc1.getIconWidth(), loadGameIc1.getIconHeight());
        loadGameBtn.setActionCommand(loadGameBtnName);
        loadGameBtn.addActionListener(this);
        loadGameBtn.addMouseListener(this);
        loadGameBtn.setVisible(true);
        mainPageJL.add(loadGameBtn);

        menuBtn = new JButton();
        menuImageIc1 = new ImageIcon("icon\\button\\menu1.jpg");
        menuImageIc2 = new ImageIcon("icon\\button\\menu2.jpg");
        menuBtn.setIcon(menuImageIc1);
        menuBtn.setBounds(1370, 620, menuImageIc1.getIconWidth(), menuImageIc1.getIconHeight());
        menuBtn.setActionCommand(menuBtnName);
        menuBtn.addActionListener(this);
        menuBtn.addMouseListener(this);
        menuBtn.setVisible(true);
        mainPageJL.add(menuBtn);
        PTextField pTextField = new PTextField("Enter your name");

        backgroundJL.setVisible(true);
        mainPageJL.add(backgroundJL);
    }

    public void exitBtnAction() {
        int a = JOptionPane.showConfirmDialog(owner, "Are you sure you want to quit this game?", "Quit", JOptionPane.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        if (a == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    public void newGameAction() {
        mainPageJL.remove(playNowBtn);
        mainPageJL.remove(loadGameBtn);
        mainPageJL.remove(menuBtn);
        mainPageJL.remove(backgroundJL);
        mainPageJL.invalidate();
        mainPageJL.repaint();

        new Timer(1, e -> Auxiliary.moveVerticalComponent(mainPageJL, newGameBtn, 200)).start();

        newGameBtn.setEnabled(false);

        backBtn = new JButton();
        backImageIc1 = new ImageIcon("icon\\button\\back1.jpg");
        backImageIc2 = new ImageIcon("icon\\button\\back2.jpg");
        backBtn.setIcon(backImageIc1);
        backBtn.setBounds(1370, 620, backImageIc1.getIconWidth(), backImageIc1.getIconHeight());
        backBtn.setActionCommand(backBtnName);
        backBtn.addActionListener(this);
        backBtn.addMouseListener(this);
        backBtn.setVisible(true);
        mainPageJL.add(backBtn);

        playerCountJL = new JLabel("Please select the count of players");
        playerCountJL.setBounds(1315, 300, 260, 50);
        playerCountJL.setFont(new Font("Verdana", Font.BOLD, 12));
        playerCountJL.setForeground(Color.WHITE);
        mainPageJL.add(playerCountJL);

        playerCountJRB1 = new JRadioButton("2");playerCountJRB1.setBounds(1310, 340, 35, 30);mainPageJL.add(playerCountJRB1);
        playerCountJRB2 = new JRadioButton("3");playerCountJRB2.setBounds(1400, 340, 35, 30);mainPageJL.add(playerCountJRB2);
        playerCountJRB3 = new JRadioButton("4");playerCountJRB3.setBounds(1490, 340, 35, 30);mainPageJL.add(playerCountJRB3);
        ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(playerCountJRB1);buttonGroup.add(playerCountJRB2);buttonGroup.add(playerCountJRB3);
        confirmBtn = new JButton();
        confirmImageIc1 = new ImageIcon("icon\\button\\confirm1.jpg");
        confirmImageIc2 = new ImageIcon("icon\\button\\confirm2.jpg");
        confirmBtn.setIcon(confirmImageIc1);
        confirmBtn.addActionListener(this);
        confirmBtn.addMouseListener(this);
        confirmBtn.setBounds(1393, 380, 50, 30);
        mainPageJL.add(confirmBtn);
        mainPageJL.add(backgroundJL);
    }

    public void confirmBtnAction() {
        int playerCount = (playerCountJRB1.isSelected() ? 2 : (playerCountJRB2.isSelected() ? 3 : (playerCountJRB3.isSelected() ? 4 : 0)));
        String player1NameStr = "", player2NameStr = "", player3NameStr = "", player4NameStr = "";
        /*if (player1Name != null) {
            player1NameStr = player1Name.getText();
            mainPageJL.remove(player1Name);
        }if(player1JL != null) mainPageJL.remove(player1JL);*/
        /*if (player2Name != null) {
            player2NameStr = player2Name.getText();
            mainPageJL.remove(player2Name);
        } if(player2JL != null) mainPageJL.remove(player2JL);*/
        if (player3Name != null) {
            player3NameStr = player3Name.getText();
            mainPageJL.remove(player3Name);
        } if(player3JL != null) mainPageJL.remove(player3JL);
        if (player4Name != null) {
            player4NameStr = player4Name.getText();
            mainPageJL.remove(player4Name);
        } if(player4JL != null) mainPageJL.remove(player4JL);


        String promptText = "Enter player's name";
        switch (playerCount) {
            case 4:
                player4Name = new PTextField(promptText);
                player4Name.setText(player4NameStr);
                player4Name.setBounds(1400, 570, 130, 30);
                mainPageJL.add(player4Name);
                player4JL = new JLabel("player 4 : ");
                player4JL.setBounds(1300, 570, 100, 30);
                player4JL.setFont(new Font("Verdana", Font.BOLD, 13));
                player4JL.setForeground(Color.CYAN);
                mainPageJL.add(player4JL);
            case 3:
                player3Name = new PTextField(promptText);
                player3Name.setText(player3NameStr);
                player3Name.setBounds(1400, 520, 130, 30);
                mainPageJL.add(player3Name);
                player3JL = new JLabel("player 3 : ");
                player3JL.setBounds(1300, 520, 100, 30);
                player3JL.setFont(new Font("Verdana", Font.BOLD, 13));
                player3JL.setForeground(Color.CYAN);
                mainPageJL.add(player3JL);
            case 2:
                player2Name = new PTextField(promptText);
                player2Name.setText(player2NameStr);
                player2Name.setBounds(1400, 470, 130, 30);
                player1Name = new PTextField(promptText);
                player1Name.setText(player1NameStr);
                player1Name.setBounds(1400, 420, 130, 30);
                mainPageJL.add(player2Name);
                mainPageJL.add(player1Name);
                player2JL = new JLabel("player 2 : ");
                player2JL.setBounds(1300, 470, 100, 30);
                player2JL.setFont(new Font("Verdana", Font.BOLD, 13));
                player2JL.setForeground(Color.CYAN);
                mainPageJL.add(player2JL);
                player1JL = new JLabel("player 1 : ");
                player1JL.setBounds(1300, 420, 100, 30);
                player1JL.setFont(new Font("Verdana", Font.BOLD, 13));
                player1JL.setForeground(Color.CYAN);
                mainPageJL.add(player1JL);
        }
        mainPageJL.add(backgroundJL);
    }


    public void backBtnAction() {
        mainPageJL.removeAll();
        mainPageJL.add(playNowBtn);
        new Timer(1, e -> Auxiliary.moveVerticalComponent(mainPageJL, newGameBtn, 360)).start();
        playNowAction();
    }
    @Override
    public void mouseClicked(MouseEvent e) {

    }
    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if (e.getSource() == playNowBtn) {
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        if (e.getSource() == playNowBtn) {
            playNowBtn.setIcon(playNowImageIc2);
        } else if (e.getSource() == optionBtn) {
            optionBtn.setIcon(optionImageIc2);
        } else if (e.getSource() == exitBtn) {
            exitBtn.setIcon(exitImageIc2);
        } else if (e.getSource() == rulesBtn) {
            rulesBtn.setIcon(rulesImageIc2);
        } else if (e.getSource() == newGameBtn) {
            newGameBtn.setIcon(newGameImageIc2);
        } else if (e.getSource() == loadGameBtn) {
            loadGameBtn.setIcon(loadGameIc2);
        } else if (e.getSource() == menuBtn) {
            menuBtn.setIcon(menuImageIc2);
        } else if (e.getSource() == backBtn) {
            backBtn.setIcon(backImageIc2);
        } else if (e.getSource() == confirmBtn) {
            confirmBtn.setIcon(confirmImageIc2);
        }
    }

    @Override
    public void mouseExited(MouseEvent e) {
        if (e.getSource() == playNowBtn) {
            playNowBtn.setIcon(playNowImageIc1);
        } else if (e.getSource() == optionBtn) {
            optionBtn.setIcon(optionImageIc1);
        } else if (e.getSource() == exitBtn) {
            exitBtn.setIcon(exitImageIc1);
        } else if (e.getSource() == rulesBtn) {
            rulesBtn.setIcon(rulesImageIc1);
        } else if (e.getSource() == newGameBtn) {
            newGameBtn.setIcon(newGameImageIc1);
        } else if (e.getSource() == loadGameBtn) {
            loadGameBtn.setIcon(loadGameIc1);
        } else if (e.getSource() == menuBtn) {
            menuBtn.setIcon(menuImageIc1);
        } else if (e.getSource() == backBtn) {
            backBtn.setIcon(backImageIc1);
        } else if (e.getSource() == confirmBtn) {
            confirmBtn.setIcon(confirmImageIc1);
        }


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == playNowBtn) {
            playNowAction();
        } else if (e.getSource() == newGameBtn) {
            newGameAction();
        } else if (e.getSource() == exitBtn) {
            exitBtnAction();
        } else if (e.getSource() == menuBtn) {
            Auxiliary.changePanel(owner, new MainPage(owner));
        } else if (e.getSource() == backBtn) {
            backBtnAction();
        } else if (e.getSource() == confirmBtn) {
            confirmBtnAction();
        } else if (e.getSource() == loadGameBtn) {
            Auxiliary.changePanel(owner, new GamePage());
        }
    }
}


