package RiskGame.UI;

import javax.swing.*;
import java.awt.*;

import static RiskGame.UI.Auxiliary.*;

public class GamePage extends JPanel {
    private JPanel gameMap;
    private ImageIcon imageIcon = new ImageIcon("Lands\\americanContinent\\usa_flag.gif");
    public GamePage() {
        addGameMap();
    }

    public void addGameMap(){
        setBounds(0, 0, WIDTH_SCREEN, HEIGHT_SCREEN);
        gameMap = new MapGUI().getMapGUIJP();
        setLayout(null);
        add(gameMap);
        setBackground(Color.ORANGE);
        setVisible(true);
    }



}
