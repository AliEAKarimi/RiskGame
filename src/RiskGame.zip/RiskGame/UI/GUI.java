package RiskGame.UI;

import javax.swing.*;

public class GUI extends JFrame {

    private LoadingPage loadingPage;
    private MainPage mainPage;

    public GUI(){
        setTitle("Risk Game");
        setExtendedState(MAXIMIZED_BOTH);
        setUndecorated(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        addLoadingPage();

        setResizable(false);
        setLocationRelativeTo(null);
        //setLayout(null);
        //setVisible(true);
    }

    public void addLoadingPage() {
        loadingPage = new LoadingPage();
        setLayout(null);
        add(loadingPage);
        setVisible(true);
        loadingPage.iterate();
        if(loadingPage.getValueOfProgressBar() == 100) {
            mainPage = new MainPage(this);
            Auxiliary.changePanel(this, mainPage);
        }
    }
}

