package RiskGame.UI;

import RiskGame.Logic.Land;
import RiskGame.Logic.Map;
import RiskGame.Logic.Ocean;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import static RiskGame.UI.Auxiliary.*;

public class MapGUI extends Map {

    private JPanel mapGUIJP;
    private String[][] addressMapIcons1;
    private String[][] addressMapIcons2;
    private JButton[][] lands;
    private String[][] landsName;

    //for Default map
    public MapGUI() {
        drawDefaultMap();
    }

    public void drawDefaultMap() {
        mapGUIJP = new JPanel();
        addressMapIcons1 = new String[][]{
            {"Lands\\american\\canada1.png", "Lands\\american\\unitedState1.png", "Lands\\europe\\denmarkMap1.png", "Lands\\europe\\polandMap1.png", "Lands\\asia\\chinaMap1.png", "Lands\\asia\\northKoreaMap1.png"},
            {"Lands\\american\\mexico1.png", "Lands\\american\\cuba1.png", "Lands\\europe\\belgiumMap1.png", "Lands\\europe\\germanyMap1.png", "Lands\\asia\\turkeyMap1.png", "Lands\\asia\\iranMap1.png"},
            {"Lands\\american\\colombia1.png", "Lands\\sea\\sea11.png", "Lands\\europe\\franceMap1.png", "Lands\\europe\\italyMap1.png", "Lands\\asia\\iraqMap1.png", "Lands\\asia\\pakistanMap1.png"},
            {"Lands\\american\\peru1.png", "Lands\\sea\\sea21.png", "Lands\\sea\\sea22.png", "Lands\\africa\\egyptMap1.png", "Lands\\asia\\indiaMap1.png", "Lands\\asia\\japanMap1.png"},
            {"Lands\\american\\brazil1.png", "Lands\\sea\\sea31.png", "Lands\\africa\\maliMap1.png", "Lands\\africa\\nigerMap1.png", "Lands\\sea\\sea34.png", "Lands\\sea\\sea35.png"},
            {"Lands\\american\\chile1.png", "Lands\\american\\argentina1.png", "Lands\\africa\\sudanMap1.png", "Lands\\africa\\kenyaMap1.png", "Lands\\sea\\sea44.png", "Lands\\sea\\sea55.png"},
            {"Lands\\sea\\sea50.png", "Lands\\sea\\sea51.png", "Lands\\africa\\zambiaMap1.png", "Lands\\sea\\sea53.png", "Lands\\sea\\sea55.png", "Lands\\sea\\sea55.png"}
        };
        addressMapIcons2 = new String[][]{
            {"Lands\\american\\canada2.png", "Lands\\american\\unitedState2.png", "Lands\\europe\\denmarkMap2.png", "Lands\\europe\\polandMap2.png", "Lands\\asia\\chinaMap2.png", "Lands\\asia\\northKoreaMap2.png"},
            {"Lands\\american\\mexico2.png", "Lands\\american\\cuba2.png", "Lands\\europe\\belgiumMap2.png", "Lands\\europe\\germanyMap2.png", "Lands\\asia\\turkeyMap2.png", "Lands\\asia\\iranMap2.png"},
            {"Lands\\american\\colombia2.png", "Lands\\sea\\sea11.png", "Lands\\europe\\franceMap2.png", "Lands\\europe\\italyMap2.png", "Lands\\asia\\iraqMap2.png", "Lands\\asia\\pakistanMap2.png"},
            {"Lands\\american\\peru2.png", "Lands\\sea\\sea21.png", "Lands\\sea\\sea22.png", "Lands\\africa\\egyptMap2.png", "Lands\\asia\\indiaMap2.png", "Lands\\asia\\japanMap2.png"},
            {"Lands\\american\\brazil2.png", "Lands\\sea\\sea31.png", "Lands\\africa\\maliMap2.png", "Lands\\africa\\nigerMap2.png", "Lands\\sea\\sea34.png", "Lands\\sea\\sea35.png"},
            {"Lands\\american\\chile2.png", "Lands\\american\\argentina2.png", "Lands\\africa\\sudanMap2.png", "Lands\\africa\\kenyaMap2.png", "Lands\\sea\\sea44.png", "Lands\\sea\\sea55.png"},
            {"Lands\\sea\\sea50.png", "Lands\\sea\\sea51.png", "Lands\\africa\\zambiaMap2.png", "Lands\\sea\\sea53.png", "Lands\\sea\\sea55.png", "Lands\\sea\\sea55.png"}
        };
        mapGUIJP.setBounds(WIDTH_SCREEN/2 - 450 , HEIGHT_SCREEN/2 - 490,900, 910);
        lands = new JButton[7][6];
        for (int i = 0 ; i < lands.length ; i++) {
            for (int j = 0 ; j < lands[i].length ; j++) {
                lands[i][j] = new JButton();
                String toolTipText = "";
                Object object = getSortedMap().get(i * 6 + j);
                if (object instanceof Land) {
                    toolTipText = ((Land) object).getName();
                } else if (object instanceof Ocean) {
                    toolTipText = ((Ocean) object).getName();
                }
                lands[i][j].setToolTipText(toolTipText);
                lands[i][j].setSize(150, 130);
                lands[i][j].setIcon(new ImageIcon(addressMapIcons1[i][j]));
                int finalI = i;
                int finalJ = j;
                lands[i][j].addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseEntered(MouseEvent e) {
                        super.mouseExited(e);
                        lands[finalI][finalJ].setIcon(new ImageIcon(addressMapIcons2[finalI][finalJ]));
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                        super.mouseEntered(e);
                        lands[finalI][finalJ].setIcon(new ImageIcon((addressMapIcons1[finalI][finalJ])));
                    }
                });
                Auxiliary.setOffBtn(lands[i][j]);
                lands[i][j].setVisible(true);
                mapGUIJP.add(lands[i][j]);
            }
        }
        mapGUIJP.setLayout(new GridLayout(7, 6));
    }

    public JPanel getMapGUIJP() {
        return mapGUIJP;
    }
}
