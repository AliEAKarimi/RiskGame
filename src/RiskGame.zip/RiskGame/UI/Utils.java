package RiskGame.UI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.Random;

public class Auxiliary {
    private static Random random;

    public static final int WIDTH_SCREEN = Toolkit.getDefaultToolkit().getScreenSize().width;
    public static final int HEIGHT_SCREEN = Toolkit.getDefaultToolkit().getScreenSize().height;

    public static int randomInteger(int min, int max) {
        random = new Random();
        return random.nextInt(max + 1 - min) + min;
    }

    public static void setOffBtn(JButton button) {
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
    }

    public static void changePanel(JFrame frame, JPanel newPanel) {
        frame.getContentPane().removeAll();
        frame.repaint();
        frame.add(newPanel);
        frame.setVisible(true);
    }

    public static void moveVerticalComponent(Component component1, Component component2, int destination) {
        if (component2.getY() < destination) {
            component2.setLocation(component2.getX(), component2.getY() + 1);
        } else {
            component2.setLocation(component2.getX(), component2.getY() - 1);
        }
        component1.invalidate();
        component1.repaint();
    }
}

class PTextField extends JTextField {
    public PTextField(final String promptText) {
        addFocusListener(new FocusListener() {

            @Override
            public void focusLost(FocusEvent e) {
                if(getText().isEmpty() || getText().equals("")) {
                    setText(promptText);
                }
            }

            @Override
            public void focusGained(FocusEvent e) {
                if(getText().equals(promptText)) {
                    setText("");
                }
            }
        });

    }

}